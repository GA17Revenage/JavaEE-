lay('#version').html('-v'+ laydate.v);

//执行一个laydate实例
laydate.render({
  elem: '#test1' //指定元素
  
});
laydate.render({
  elem: '#test2' //指定元素
  
});
laydate.render({
  elem: '#test3' //指定元素
  
});