/*������Ϣ��֤*/
$(function() {
		/*�˿͵�¼��Ϣ��֤*/	
		$(".customer_login_error").Validform({
			tiptype : function(msg, o, cssctl) {
				var objtip = $(".customer_error_box");
				cssctl(objtip, o.type);
				objtip.text(msg);
			},

		});
		/*Ա����¼��Ϣ��֤*/
		$(".staff_login_error").Validform({
			tiptype : function(msg, o, cssctl) {
				var objtip = $(".staff_error_box");
				cssctl(objtip, o.type);
				objtip.text(msg);
			},

		});
		/*����Ա��¼��Ϣ��֤*/
		$(".admin_login_error").Validform({
			tiptype : function(msg, o, cssctl) {
				var objtip = $(".admin_error_box");
				cssctl(objtip, o.type);
				objtip.text(msg);
			},
		});
	});